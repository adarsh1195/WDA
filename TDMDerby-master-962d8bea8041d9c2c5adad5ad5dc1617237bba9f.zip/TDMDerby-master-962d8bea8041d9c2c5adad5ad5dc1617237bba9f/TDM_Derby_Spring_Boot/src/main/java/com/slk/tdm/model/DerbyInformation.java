package com.slk.tdm.model;

public class DerbyInformation {
	public DerbyInformation(String database_type, String hostname, int portnumber, String message) {
		super();
		this.database_type = database_type;
		this.hostname = hostname;
		this.portnumber = portnumber;
		this.message = message;
	}
	private String database_type;
	private String hostname;
	private int portnumber;
	private String message;

	
	public String getDatabase_type() {
		return database_type;
	}
	public void setDatabase_type(String database_type) {
		this.database_type = database_type;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public int getPortnumber() {
		return portnumber;
	}
	public void setPortnumber(int portnumber) {
		this.portnumber = portnumber;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	
	

}
