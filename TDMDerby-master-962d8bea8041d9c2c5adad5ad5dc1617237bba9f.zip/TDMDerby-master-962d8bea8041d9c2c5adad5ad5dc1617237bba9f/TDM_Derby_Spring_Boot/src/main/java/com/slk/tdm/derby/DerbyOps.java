package com.slk.tdm.derby;

import java.io.PrintWriter;
import java.net.InetAddress;

import java.util.Properties;

import org.apache.derby.drda.NetworkServerControl;

import com.slk.tdm.model.DerbyInformation;
import com.slk.tdm.model.DerbyStatusInfo;

public class DerbyOps {
	
	static final String databasetype = "derby";

	static NetworkServerControl server = null;

	private static DerbyOps derbyOps = null;

	static DerbyInformation derbyinfo = null;
	
	static String hostname;
	static int portnumber;

	public static DerbyOps getInstance() {

		if (derbyOps == null) {

			derbyOps = new DerbyOps();

		}

		return derbyOps;
	}
	

	
	public DerbyInformation startServer(String hostname, int portnumber) {

		this.hostname = hostname;
		this.portnumber = portnumber;
		
		if (!checkServerStatus()) {

			System.out.println("creating new connection");
			InetAddress address;
			try {
				address = InetAddress.getByName(hostname);
				server = new NetworkServerControl(address, portnumber);
				server.start(new PrintWriter(System.out));
				Runtime.getRuntime().addShutdownHook(shutdownHook(server));

			} catch (Exception e) {

				System.out.println("StartServerException");

				e.printStackTrace();

			}

		}

		String connProps = getConnectionProperties();

		if (connProps.contains("java.lang.Exception")) {

			//derbyinfo = new DerbyInformation("java.lang.Exception", null, hostname, portnumber);

		} else {
			derbyinfo = new DerbyInformation(databasetype, hostname, portnumber, "Successfully instantiated.");

		}
		return derbyinfo;

	}

	public String getConnectionProperties() {

		// jdbc:derby://localhost:1527/myDB

		String derbyURL = "jdbc:derby://";

		try {
			Properties props = server.getCurrentProperties();

			derbyURL += props.getProperty("derby.drda.host") + ":" + props.getProperty("derby.drda.portNumber") + "/";

		} catch (Exception e) {

			System.out.println("getConnectionPropsException");

			System.out.println(e.getClass().toString());
			e.printStackTrace();
			

			return e.getClass().toString();

		}

		return derbyURL;

	}

	public static Thread shutdownHook(final NetworkServerControl server) {
		return new Thread() {
			@Override
			public void run() {
				try {
					server.shutdown();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
	}

	public boolean stopServer() {

		try {

			
			
			server.shutdown();
			// Thread t = shutdownHook(server);
			server = null;
			// server.getSysinfo();
			// shutdownHook();
			
			return true;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}

	public void pingServer() {
		try {
			server.ping();
		} catch (Exception e) {
			System.out.println("Server is not on");
			e.printStackTrace();
		}
	}

	public boolean checkServerStatus() {

		try {
			server.ping();

			return true;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}

	}
	
	public DerbyStatusInfo derbyStatus() {
		
		System.out.println("In Status");
		System.out.println(hostname+" "+ portnumber);
		
		DerbyStatusInfo dbInfo ;
		try {
			server.ping();

			 dbInfo = new DerbyStatusInfo("Alive", databasetype, hostname, portnumber);

		} catch (Exception e) {
			
			// TODO Auto-generated catch block
			 dbInfo = new DerbyStatusInfo("Dead", "", "", 0);
		}

		return dbInfo;
		
	}

}
