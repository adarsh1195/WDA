package com.slk.tdm.controller;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("derby")

public class AppProperties {

	private String hostname;
	private String port1;
	private String port2;
	private String port3;
	private String port4;
	private String port5;

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getPort1() {
		return port1;
	}

	public void setPort1(String port1) {
		this.port1 = port1;
	}

	public String getPort2() {
		return port2;
	}

	public void setPort2(String port2) {
		this.port2 = port2;
	}

	public String getPort3() {
		return port3;
	}

	public void setPort3(String port3) {
		this.port3 = port3;
	}

	public String getPort4() {
		return port4;
	}

	public void setPort4(String port4) {
		this.port4 = port4;
	}

	public String getPort5() {
		return port5;
	}

	public void setPort5(String port5) {
		this.port5 = port5;
	}

}
