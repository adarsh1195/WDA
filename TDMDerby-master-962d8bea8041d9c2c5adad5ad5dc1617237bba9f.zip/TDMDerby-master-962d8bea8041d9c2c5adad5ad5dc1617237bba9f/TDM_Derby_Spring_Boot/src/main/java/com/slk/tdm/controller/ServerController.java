package com.slk.tdm.controller;


import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.slk.tdm.derby.DerbyOps;
import com.slk.tdm.model.DerbyInformation;
import com.slk.tdm.model.DerbyStatusInfo;

@RestController
public class ServerController {

	@Autowired
	AppProperties myAppProperties;

	@RequestMapping("/tdmdbstart")
	public DerbyInformation startServer() {

		System.out.println("on Service " + myAppProperties.getHostname());

		DerbyOps dops = new DerbyOps();

		System.out.println("myAppProperties " + myAppProperties.getHostname());

		// DerbyInformation dbinfo = dops.startServer();

		// System.out.println(dbinfo.getConnection_string());
		// System.out.println(dbinfo.getError());

		DerbyInformation dbinfo1 = null;

		dbinfo1 = dops.startServer(myAppProperties.getHostname(), Integer.parseInt(myAppProperties.getPort1()));

		return dbinfo1;

	}

	@RequestMapping("/tdmdbstop")
	public boolean stopServer() {

		System.out.println("off Service");
		DerbyOps dops = new DerbyOps();
		
		boolean isStopped = dops.stopServer();

		return isStopped;

	}

	@RequestMapping("/tdmdbstatus")
	public DerbyStatusInfo serverStatus() {

		System.out.println("server status");
		DerbyOps dops = new DerbyOps();
		DerbyStatusInfo isActive = dops.derbyStatus();

		return isActive;

	}

}
