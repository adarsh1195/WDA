package com.slk.tdm.model;

public class DerbyStatusInfo {

	private String status;
	private String database_type;
	private String hostname;
	private int portnumber;

	public DerbyStatusInfo(String status, String database_type, String hostname, int portnumber) {
		super();
		this.status = status;
		this.database_type = database_type;
		this.hostname = hostname;
		this.portnumber = portnumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDatabase_type() {
		return database_type;
	}

	public void setDatabase_type(String database_type) {
		this.database_type = database_type;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public int getPortnumber() {
		return portnumber;
	}

	public void setPortnumber(int portnumber) {
		this.portnumber = portnumber;
	}

}
